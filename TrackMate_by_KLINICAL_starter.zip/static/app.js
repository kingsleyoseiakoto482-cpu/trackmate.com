const $ = id => document.getElementById(id);
let session = null, watchId = null, pollTimer = null, installPrompt = null;
const setNotice = (message, type="") => { $("notice").textContent = message; $("notice").className = "notice " + type; };
const getDeviceInfo = () => ({
  name: $("deviceName").value.trim() || "My device",
  phone: $("phoneNumber").value.trim()
});
async function api(url, body) {
  const response = await fetch(url, {
    method: body ? "POST" : "GET",
    headers: body ? {"Content-Type":"application/json"} : {},
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function activateSession(data) {
  session = data;
  $("session").hidden = false;
  $("codeDisplay").textContent = data.code;
  $("shareBtn").hidden = false;
  $("stopBtn").hidden = true;
  $("shareBtn").disabled = false;
  setNotice("Connected to pairing room. On the other device, enter this same code.", "success");
  startPolling();
}
$("createBtn").addEventListener("click", async () => {
  try { const data = await api("/api/pair", getDeviceInfo()); activateSession(data); }
  catch(e) { setNotice(e.message, "error"); }
});
$("joinBtn").addEventListener("click", async () => {
  const code = $("pairCode").value.trim().toUpperCase();
  if (!code) return setNotice("Enter the pairing code from the other device.", "error");
  try { const data = await api("/api/pair", {...getDeviceInfo(), code}); activateSession(data); }
  catch(e) { setNotice(e.message, "error"); }
});
$("copyBtn").addEventListener("click", async () => {
  if (!session) return;
  try { await navigator.clipboard.writeText(session.code); $("copyBtn").textContent = "Copied!"; }
  catch { setNotice("Your code is " + session.code + ". Copy it manually.", "success"); }
});
$("shareBtn").addEventListener("click", () => {
  if (!session) return;
  if (!("geolocation" in navigator)) return setNotice("This browser does not support GPS location sharing.", "error");
  if (!window.isSecureContext && location.hostname !== "localhost") return setNotice("GPS sharing requires HTTPS. Open TrackMate using a secure HTTPS address.", "error");
  $("shareBtn").disabled = true;
  setNotice("Waiting for you to approve the location permission…");
  watchId = navigator.geolocation.watchPosition(async pos => {
    try {
      await api("/api/location", {code:session.code, device_id:session.device_id,
        lat:pos.coords.latitude, lon:pos.coords.longitude, accuracy:pos.coords.accuracy});
      $("shareBtn").hidden = true; $("shareBtn").disabled = false; $("stopBtn").hidden = false;
      setNotice("Your location is being shared with devices in this pairing room. Press Stop sharing to end.", "success");
      renderMyCoordinates(pos.coords.latitude, pos.coords.longitude);
    } catch(e) { setNotice(e.message, "error"); stopSharing(false); }
  }, err => {
    $("shareBtn").disabled = false;
    const msg = err.code === 1 ? "Location permission was denied. Allow it in browser settings if you want to share." :
      err.code === 2 ? "Your location is unavailable. Try moving outdoors or checking GPS settings." :
      "Location timed out. Please try again.";
    setNotice(msg, "error");
  }, {enableHighAccuracy:true, maximumAge:3000, timeout:20000});
});
function stopSharing(showMessage=true) {
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  watchId = null; $("shareBtn").hidden = false; $("shareBtn").disabled = false; $("stopBtn").hidden = true;
  if (showMessage) setNotice("Location sharing stopped on this device.", "success");
}
$("stopBtn").addEventListener("click", () => stopSharing(true));
function renderMyCoordinates(lat, lon) { window.myTrackMatePosition = {lat, lon}; }
function distanceMeters(a,b,c,d) {
  const rad = n => n * Math.PI / 180, R = 6371000;
  const dLat = rad(c-a), dLon = rad(d-b);
  const x = Math.sin(dLat/2)**2 + Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}
function fmtDistance(m) { return m < 1000 ? Math.round(m).toLocaleString()+" m" : (m/1000).toFixed(2)+" km ("+Math.round(m).toLocaleString()+" m)"; }
function fmtAge(timestamp) {
  if (!timestamp) return "No location shared yet";
  const sec = Math.max(0, Math.floor(Date.now()/1000-timestamp));
  return sec < 60 ? `Updated ${sec} seconds ago` : `Updated ${Math.floor(sec/60)} minutes ago`;
}
async function pollLocations() {
  if (!session) return;
  try {
    const data = await api(`/api/locations?code=${encodeURIComponent(session.code)}&device_id=${encodeURIComponent(session.device_id)}`);
    const other = data.devices.find(d => d.lat !== null && d.lon !== null);
    if (!other) { $("emptyState").hidden = false; $("locationCard").hidden = true; return; }
    $("emptyState").hidden = true; $("locationCard").hidden = false;
    $("otherName").textContent = other.name || "Paired device";
    $("otherPhone").textContent = other.phone || "Phone number not provided";
    $("lat").textContent = Number(other.lat).toFixed(5);
    $("lon").textContent = Number(other.lon).toFixed(5);
    $("accuracy").textContent = other.accuracy == null ? "Unknown" : `±${Math.round(other.accuracy)} m`;
    $("mapLink").href = `https://www.openstreetmap.org/?mlat=${other.lat}&mlon=${other.lon}#map=17/${other.lat}/${other.lon}`;
    $("updatedAt").textContent = fmtAge(other.updated);
    if (window.myTrackMatePosition) {
      const p = window.myTrackMatePosition;
      $("distance").textContent = fmtDistance(distanceMeters(p.lat,p.lon,other.lat,other.lon));
    } else $("distance").textContent = "Share your GPS to calculate distance";
  } catch(e) { setNotice(e.message, "error"); }
}
function startPolling() { if (pollTimer) clearInterval(pollTimer); pollLocations(); pollTimer = setInterval(pollLocations, 3000); }
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); installPrompt = e; $("installBtn").hidden = false; });
$("installBtn").addEventListener("click", async () => {
  if (installPrompt) {
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null; $("installBtn").hidden = true;
  } else {
    setNotice("On iPhone, use Safari → Share → Add to Home Screen. On Android, open the browser menu and choose Install app or Add to Home screen.", "success");
  }
});
if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("/sw.js").catch(()=>{});
