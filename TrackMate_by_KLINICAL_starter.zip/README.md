# TrackMate by KLINICAL

A starter Progressive Web App for **consent-based** location sharing between paired devices.

## What it does
- Creates a temporary pairing code on one device; another device joins with that code.
- Lets each device owner explicitly press **Start sharing my location** and approve the browser's GPS prompt.
- Shows the other paired device's last shared coordinates, GPS accuracy, map link, and straight-line distance when both devices share GPS.
- Includes an install button for browsers that support PWA installation, a web app manifest, service worker, and icon.
- Labels a phone number if entered. **It does not locate a phone by phone number.**

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000. For two-device testing, deploy to an HTTPS host and open the same URL on both phones. GPS is generally blocked on non-HTTPS sites except localhost.

## Important limitations before public launch
This is a learning/demo starter, not a production tracking service:
- Demo rooms are stored in server memory and vanish on restart.
- No accounts, robust authentication, database, room expiry, or abuse protection are included.
- Do not use it to track someone without their informed permission.
- Use HTTPS and a production WSGI server for deployment. Add secure authentication, expiring/invite-only pairings, database persistence, rate limits, deletion controls, and a clear privacy policy before real users.
- PWA installation is browser-controlled; a website cannot force-install itself or guarantee every browser shows the install prompt.

## Deploy (example)
On a Python hosting service, set build/install command to `pip install -r requirements.txt` and start command to `gunicorn app:app` after adding `gunicorn` to `requirements.txt`. Configure HTTPS in the hosting dashboard.
