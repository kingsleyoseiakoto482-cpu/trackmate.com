from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
from threading import Lock
import secrets, time, os

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)
lock = Lock()

# Demo storage only: data is lost when the server restarts.
# For a real public launch, use a database, authenticated accounts, HTTPS,
# rate limiting, and expiring pairing invitations.
rooms = {}  # room_code -> {devices: {device_id: {name, phone, lat, lon, accuracy, updated}}}

def clean_text(value, limit=50):
    return str(value or "").strip()[:limit]

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json")

@app.get("/sw.js")
def service_worker():
    response = send_from_directory("static", "sw.js")
    response.headers["Service-Worker-Allowed"] = "/"
    return response

@app.post("/api/pair")
def pair():
    data = request.get_json(silent=True) or {}
    name = clean_text(data.get("name"), 40) or "My device"
    phone = clean_text(data.get("phone"), 24)  # label only; never used to locate a phone
    with lock:
        code = clean_text(data.get("code"), 12).upper()
        if code:
            if code not in rooms:
                return jsonify(error="That pairing code was not found. Ask the other device to create a room first."), 404
        else:
            code = secrets.token_urlsafe(5).replace("-", "").replace("_", "").upper()[:8]
            while code in rooms:
                code = secrets.token_hex(4).upper()
            rooms[code] = {"devices": {}}
        device_id = secrets.token_urlsafe(18)
        rooms[code]["devices"][device_id] = {
            "name": name, "phone": phone, "lat": None, "lon": None,
            "accuracy": None, "updated": None
        }
    return jsonify(code=code, device_id=device_id, message="Paired. Turn on location sharing when you are ready.")

@app.post("/api/location")
def update_location():
    data = request.get_json(silent=True) or {}
    code = clean_text(data.get("code"), 12).upper()
    device_id = clean_text(data.get("device_id"), 100)
    try:
        lat, lon = float(data["lat"]), float(data["lon"])
        accuracy = float(data.get("accuracy", 0))
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Valid GPS coordinates are required."), 400
    with lock:
        room = rooms.get(code)
        if not room or device_id not in room["devices"]:
            return jsonify(error="Pairing session not found. Pair again."), 404
        device = room["devices"][device_id]
        device.update(lat=lat, lon=lon, accuracy=accuracy, updated=time.time())
    return jsonify(ok=True)

@app.get("/api/locations")
def locations():
    code = clean_text(request.args.get("code"), 12).upper()
    device_id = clean_text(request.args.get("device_id"), 100)
    with lock:
        room = rooms.get(code)
        if not room or device_id not in room["devices"]:
            return jsonify(error="Pairing session not found."), 404
        result = []
        for key, device in room["devices"].items():
            if key == device_id:
                continue
            result.append({
                "name": device["name"], "phone": device["phone"],
                "lat": device["lat"], "lon": device["lon"],
                "accuracy": device["accuracy"], "updated": device["updated"]
            })
    return jsonify(devices=result)

@app.get("/health")
def health():
    return jsonify(status="ok", app="TrackMate by KLINICAL")

if __name__ == "__main__":
    # For local testing only. Use a production WSGI server when deploying.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
